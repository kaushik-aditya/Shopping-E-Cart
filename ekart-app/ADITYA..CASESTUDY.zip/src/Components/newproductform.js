
import React, { useContext, useState } from 'react';
import { TextField, Button, Typography } from '@mui/material';
import { Row } from 'react-bootstrap';
import { Col } from 'react-bootstrap';
import { AuthContext } from '../App';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const initialProductData = {
    productBrand: '',
    productCategory: '',
    productDetails: '',
    productName: '',
    productPrice: '',
    productSubCategory: '',
};

export default function NewProductForm() {
    const navigate = useNavigate();
    const token = localStorage.getItem("token");

    const [productData, setProductData] = useState(initialProductData);

    const handleChange = (event) => {
        const { name, value } = event.target;
        setProductData({ ...productData, [name]: value });// For demonstration purposes, we'll just log the data. value });
    };

    const handleSubmit = async (event) => {
        event.preventDefault();        
        const url = 'http://localhost:8080/products/addProduct';
        try {
            // Send the productData to the server using an HTTP POST request with the token
            const response = await axios.post(url, productData,
                {
                headers: {
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json', // Set the Content-Type to JSON

                },
                }
            );
            if (response.status === 201) {
                navigate("/all_products");
            } 
        } catch (error) {
            // Handle any errors
            console.error('Error sending product data:', error);
        }

        console.log('Product Data:', productData);
    };
    const formComponent = {
        margin: "50px",
        padding: "20px",
        backgroundColor: "#dcefee",  // You can choose any color you prefer
        border: "2px solid #333",  // You can adjust the border style and color
        borderRadius: "10px",  // Add rounded corners for a better look
        display: "flex",
        flexDirection: "column", // Stack children vertically
        alignItems: "center",    // Center horizontally
        justifyContent: "center"
    };

    return (
        <Row>
            <Col md={2}></Col>
            <Col md={6}>
                <form style={formComponent} onSubmit={handleSubmit}>
                    <Typography variant="h5" >Add Product</Typography>
                    {Object.keys(productData).map((key) => (
                        <TextField
                            key={key}
                            name={key}
                            label={key.substring(7)}
                            value={productData[key]}
                            onChange={handleChange}

                            variant="outlined"
                            margin="normal"
                            style={{ width: "70%" }}
                        />
                    ))}
                    <Button type="submit" variant="contained" color="primary" style={{ width: "40%" }}>
                        Submit
                    </Button>
                </form>
            </Col>
            <Col md={4}></Col>
        </Row>

    );
}
