import * as React from "react";
import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import Toolbar from "@mui/material/Toolbar";
import { Button } from "@mui/material";
import ShoppingCartIcon from "@mui/icons-material/ShoppingCart";
import { styled, alpha } from "@mui/material/styles";
import InputBase from "@mui/material/InputBase";
import SearchIcon from "@mui/icons-material/Search";
import AccountCircleIcon from "@mui/icons-material/AccountCircle";
import axios from "axios";
import { AuthContext } from "../App";
import { useEffect } from "react";


export default function HomeNavbar({ onNewComponentOpen }) {
  const { setModifiedProducts } = React.useContext(AuthContext);
  const [searchString, setSearchString] = React.useState("");

  const token = localStorage.getItem("token");
  const config = {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  };

  const Search = styled("div")(({ theme }) => ({
    position: "relative",
    borderRadius: theme.shape.borderRadius,
    backgroundColor: alpha(theme.palette.common.white, 0.15),
    "&:hover": {
      backgroundColor: alpha(theme.palette.common.white, 0.25),
    },
    marginLeft: 0,
    width: "100%",
    [theme.breakpoints.up("sm")]: {
      marginLeft: theme.spacing(1),
      width: "auto",
    },
  }));

  const SearchIconWrapper = styled("div")(({ theme }) => ({
    padding: theme.spacing(0, 2),
    height: "100%",
    position: "absolute",
    pointerEvents: "none",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  }));

  const StyledInputBase = styled(InputBase)(({ theme }) => ({
    color: "#275c5e",
    "& .MuiInputBase-input": {
      padding: theme.spacing(1, 1, 1, 0),
      // vertical padding + font size from searchIcon
      paddingLeft: `calc(1em + ${theme.spacing(4)})`,
      transition: theme.transitions.create("width"),
      width: "100%",
      [theme.breakpoints.up("sm")]: {
        width: "20ch",
        "&:focus": {
          width: "30ch",
        },
      },
    },
  }));

  const fetchData = async (keyWord) => {
    const urlSearch = "http://localhost:8080/products/search/" + keyWord;

    try {
      const response = await axios.get(urlSearch, config);
      return response.data;
    } catch (error) {
      // Handle errors here
      console.error("Error searching products:", error);
    }
  };
  useEffect(() => {
    try {
      const newProducts =  fetchData(searchString);
      setModifiedProducts(newProducts);
      console.log("setting up produicts in appbar");
    } catch (error) {
      console.error("Error fetching products:", error);
    }

  }, [searchString])

  useEffect(() => {
    console.log("sdkcfjhsdk")
  
  }, )
  

  const handleSearch = async (event) => {
    setSearchString(event.target.value);


  };

  return (
    <Box>
      <AppBar position="static" sx={{ backgroundColor: "#f0a8ab" }}>
        <Toolbar>
          <Button
            variant="outlined"
            color="primary"
            size="large"
            sx={{ marginLeft: "10px", marginRight: "auto", color: "red" }}
            href="/"
          >
            EKart
          </Button>
          <Search>
            <SearchIconWrapper>
              <SearchIcon />
            </SearchIconWrapper>
            <StyledInputBase
              placeholder="Search for Products.."
              inputProps={{ "aria-label": "search" }}
              value={searchString}
              onChange={(E)=>handleSearch(E)}
            />
          </Search>
          <Button sx={{ marginLeft: "16px" }} onClick={onNewComponentOpen}>
            <AccountCircleIcon />
            Profile
          </Button>
          <Button sx={{ marginLeft: "16px" }} href="/user_cart">
            <ShoppingCartIcon />
            Cart
          </Button>
        </Toolbar>
      </AppBar>
    </Box>
  );
}
