import React, {  useState } from 'react';
import Modal from '@mui/material/Modal';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import { Typography } from '@mui/material';

export default function UserModal({ open = false, onClose, onSubmit }) {
    const  user  = JSON.parse(localStorage.getItem("user"));
    const [hasChanged, setHasChanged] = useState(false);

    // Create a local copy of user data for editing
    const [formData, setFormData] = useState({
        userName: user.userName,
        userEmail: user.userEmail,
        userPhoneNumber: user.userPhoneNumber,
        userAddress: {
            city: user.userAddress.city,
            state: user.userAddress.state,
            street: user.userAddress.street,
            pincode: user.userAddress.pincode
        }
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setHasChanged(true);

        // If the field name includes a dot ('.'), it's a nested field (e.g., Address.city)
        if (name.includes('.')) {
            const [parent, child] = name.split('.'); // Split the field name into parent and child
            setFormData({
                ...formData,
                [parent]: {
                    ...formData[parent],
                    [child]: value,
                },
            });
        } else {
            // If it's not a nested field, update it directly
            setFormData({
                ...formData,
                [name]: value,
            });
        }
    };

    const handleSubmit = (event) => {
        event.preventDefault();
        if (hasChanged) {
            // Add the new properties to formData
            const updatedFormData = {
                ...formData,
                userId: user.userId, // Add userId
                userType: user.userType, // Add userType
            };
    
            onSubmit(updatedFormData);
        }
        onClose();
    };

    const style = {
        position: 'absolute',
        top: '30%',
        left: '60%',
        transform: 'translate(-50%, -50%)',
        bgcolor: 'cream', // Change the bgcolor to your desired cream color
        border: '2px solid #000',
        boxShadow: 24,
        p: 4,
        width: "70%", // Increase the width to make it wider
        height: "60%", // Set a specific height
        overflow: 'auto', // Add the overflow property for scrolling
    };

    return (
        <Modal open={open} onClose={onClose}>
            <Box sx={style}>
                <Typography variant="h3" sx={{ margin: 'auto' }}>
                    Edit User
                </Typography>
                {Object.keys(formData).map((field) => (
                    <div key={field}>
                        {typeof formData[field] === 'object' ? (
                            <div>
                                {/* <Typography variant="h6" sx={{ marginTop: 2 }}>
                                    {field}
                                </Typography> */}
                                {Object.keys(formData[field]).map((addressField) => (
                                    <TextField
                                        key={addressField}
                                        name={`userAddress.${addressField}.`}
                                        label={addressField}
                                        value={formData[field][addressField]}
                                        onChange={handleChange}
                                        fullWidth
                                        margin="normal"
                                    />
                                ))}
                            </div>
                        ) : (
                            <TextField
                                key={field}
                                name={field}
                                label={field.substring(4)}
                                value={formData[field]}
                                onChange={handleChange}
                                fullWidth
                                margin="normal"
                            />
                        )}
                    </div>
                ))}

                <Button variant="contained" onClick={handleSubmit}>
                    Submit
                </Button>
            </Box>
        </Modal>


    );
}


