import React from 'react'
import { useLocation } from 'react-router-dom';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';


export default function ProductPreview() {
    const location = useLocation();

    // Access the product object from the state
    const product = location.state.product;
    return (
        <Card  sx={{ maxWidth: 900 , m : "auto"}}>
            <CardMedia
                sx={{ maxWidth: 500 ,m : "auto"}}
                component="img"
                alt={product.productName}
                height="200"
                image={product.productImage} // Make sure to provide the product image URL
            />
            <CardContent>
                <Typography gutterBottom variant="h5" component="div">
                    {product.productName}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                    <strong>Brand:</strong> {product.productBrand}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                    <strong>Category:</strong> {product.productCategory}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                    <strong>Subcategory:</strong> {product.productSubCategory}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                    <strong>Price:</strong> Rs.{product.productPrice}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                    <strong>Details:</strong>{product.productDetails}
                </Typography>
            </CardContent>
        </Card>
    )
}
