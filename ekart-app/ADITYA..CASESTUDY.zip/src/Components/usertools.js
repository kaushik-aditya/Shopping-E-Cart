import { Container, Button, Typography, Divider } from "@mui/material";

import { useContext } from "react";
import LoginIcon from "@mui/icons-material/Login";
import PersonAddAltRoundedIcon from "@mui/icons-material/PersonAddAltRounded";
import { AuthContext } from "../App";
import CloseIcon from "@mui/icons-material/Close";
import { Grid } from "@mui/material";
import ExitToAppIcon from "@mui/icons-material/ExitToApp";

export default function UserTools({ onNewComponentClose, openUserModal }) {
  const user = JSON.parse(localStorage.getItem("user"));
  console.log(user);
  const { isLoggedIn } = useContext(AuthContext);
  let isAdmin = false;
  if (user != null) isAdmin = user.userType === "ADMIN";
  console.log(isAdmin);
  const componentStyle = {
    backgroundColor: "#f5eae9",
    height: "100vh",
    fontSize: "60%",
  };
  const buttonStyles = {
    textTransform: "none",
    color: "black",
    fontWeight: "normal",
  };
  return (
    <Container style={componentStyle} m={0} p={1}>
      <Button
        color="secondary"
        aria-label="close"
        onClick={onNewComponentClose}
        sx={buttonStyles}
      >
        <CloseIcon />
      </Button>
      {!isLoggedIn ? (
        <Container>
          <Typography variant="h5" mb={2}>
            Welcome to Ekart.
          </Typography>
          <Divider color="red" />

          <Grid mt={2} mb={1}>
            <Grid item md={12}>
              <Typography>New User?</Typography>
              <Button href="/sign_in" sx={buttonStyles}>
                <PersonAddAltRoundedIcon />
                Sign Up
              </Button>
            </Grid>
          </Grid>
          <Divider color="red" />

          <Grid mt={2} mb={1}>
            <Grid item md={12}>
              <Typography>Already Have an account?</Typography>
              <Button href="/log_in" sx={buttonStyles}>
                <LoginIcon />
                Log In
              </Button>
            </Grid>
          </Grid>
        </Container>
      ) : (
        <Container>
          {/* profile picture */}
          <Typography mt={1} mb={1}>
            Hello {user.userName}
          </Typography>
          <Typography mt={1} mb={1}>
            {user.userPhoneNumber}
          </Typography>
          <Divider color="red" />

          <Button mt={1} href="/order_details" sx={buttonStyles}>
            Your Orders
          </Button>
          {isAdmin && (
            <Button mt={1} href="/all_products" sx={buttonStyles}>
              Products
            </Button>
          )}

          <Button variant="text" onClick={openUserModal} sx={buttonStyles}>
            Update Profile
          </Button>

          <Button href="/log_in" sx={buttonStyles}>
            LogIn Another Account
          </Button>

          <Button href="/log_out" sx={buttonStyles}>
            <ExitToAppIcon />
            LogOut
          </Button>
        </Container>
      )}
      <Divider />
    </Container>
  );
}
