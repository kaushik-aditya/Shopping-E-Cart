import React from 'react'
import { Routes, Route, } from 'react-router-dom'
import LoginPage from './login';
import Logout from './logout';
import SignUpPage from './signuppage';
import EditProducts from './editproducts';
import NewProductForm from './newproductform';
import ProductDetails from './productdetails';
import ProductPreview from './productpreview';
import ProductPreOrder from './productpreOrder';
import CheckOut from './checkout';
import CartProducts from './cartproduct';
import OrderDetails from './orderdetails';
export default function PageRoutes({logOut,setToken,setUser}) {
    return (
        <>
            <Routes>
                <Route path="/" element={<ProductDetails />} />
                <Route path="/log_out" element={<Logout logout={logOut} />} />
                <Route path="/log_in" element={<LoginPage  />} />
                <Route path="/add_product" element ={<NewProductForm />} />
                <Route path="/all_products" element = {<EditProducts />} />
                <Route path="/product_preview" element={<ProductPreview />} />
                <Route path="/product_cart" element={<ProductPreOrder />} />
                <Route path="/product_checkout" element={<CheckOut />} />
                <Route path="/user_cart" element={<CartProducts />} />
                <Route path="/order_details" element={<OrderDetails />} />
                <Route path="/sign_in" element={<SignUpPage />} />
            </Routes>
        </>
    )
}
