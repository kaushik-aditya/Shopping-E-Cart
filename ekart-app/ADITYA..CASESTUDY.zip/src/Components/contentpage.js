import ProductDetails from "./productdetails";

export default function ContentPage() {
    return (
        <>
            this is product component
            <ProductDetails />
        </>

    );
}