
import React, { useEffect, useState } from "react";
import axios from "axios";
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Typography from '@mui/material/Typography';

export default function OrderDetails() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);


  const token = localStorage.getItem("token");


  const config = {
    headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
  };
  const userData = localStorage.getItem("user");
  let userId = null;

  if (userData) {
    userId = JSON.parse(userData);
    // Now you can use userId here
  } else {
    // Handle the case when "user" data is not present in localStorage
    console.log("User data not found in localStorage.");
    // You can choose to display an error message, redirect the user, or take any other appropriate action.
  }  useEffect(() => {
  async function fetchOrders() {
    try {
      const url = "http://localhost:8080/order/" + userId + "/getOrders";
      const response = await axios.get(url, config);
      setOrders(response.data);
      setLoading(false);
    } catch (error) {
      setError(error);
      setLoading(false);
    }
  }

  fetchOrders();
}, []); // Empty dependency array, runs once on mount

useEffect(() => {
  console.log(orders); // Log the updated orders
}, [orders]);

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>Error: {error.message}</div>;
  }

  return (
    
    <div>
    {orders.map((order, index) => (
      <Card>
      <CardContent>
        
        <Typography variant="body2" color="text.secondary">
          Product Name: {order.product.productName}
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Quantity: {order.quantity}
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Delivered: {order.delivered ? 'Yes' : 'No'}
        </Typography>
      </CardContent>
    </Card>
    ))}
  </div>
  );
}

