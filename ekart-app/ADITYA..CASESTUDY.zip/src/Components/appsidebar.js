import * as React from 'react';

import List from '@mui/material/List';
import Divider from '@mui/material/Divider';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemText from '@mui/material/ListItemText';

import { Container } from '@mui/material';


export default function AppSideBar() {

    
    const tools = [
        "Brand" , "Price"
    ];
    return (



        <Container fluid>
            <h4>Filter</h4>
            <div
                style={{
                    backgroundColor: "lightblue",
                    height: "30em",
                    display: "flex",
                }}
            >
                <List>
                    {tools.map((text, index) => (
                        <ListItem key={text} disablePadding>
                            <ListItemButton>
                                
                                <ListItemText primary={text} color='Blue' />
                            </ListItemButton>
                            <Divider />
                        </ListItem>
                        
                    ))}
                </List>
                
                

            </div>
        </Container>


    );
}
