import React, { useState, useEffect } from 'react';
import {
    Card,
    CardContent,
    Checkbox,
    ListItem,
    ListItemText,
    ListItemSecondaryAction,
    FormControlLabel,
} from '@mui/material';
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import RemoveCircleOutlineIcon from '@mui/icons-material/RemoveCircleOutline';
import { IconButton } from '@mui/material';
import axios from 'axios';

export default function CartProductsTemplate({ cartProducts, selectedItems, setSelectedItems }) {

    const [currentCartProduct, setCurrentCartProduct] = useState(JSON.parse(JSON.stringify(cartProducts)));
    const token = localStorage.getItem("token");
    const { userId } = JSON.parse(localStorage.getItem("user"));
    const config = {
        headers: {
            Authorization: `Bearer ${token}`,
        },
    };

    useEffect(() => {
      
    
      console.log(currentCartProduct)
    }, [currentCartProduct])
    


    const handleCheckboxToggle = (currentCartProduct) => {

        const currentIndex = selectedItems.findIndex(e => e.cartProductId === currentCartProduct.cartProductId);
        const newSelected = [...selectedItems];

        if (currentIndex === -1) {
            console.log("not found");
            newSelected.push(currentCartProduct);
        } else {
            newSelected.splice(currentIndex, 1);
        }
        console.log(newSelected);
        setSelectedItems(newSelected);
        
    };

        // useEffect(() => {
        //     console.log(selectedItems);
        
        
        // }, [currentCartProduct])
    


    // when the checkbox is ticked and i am increasing quantity
    // it will handle pricing accordingly
    const handleQuantityChange = (CartProduct) => {
        console.log("checkboxed change")
        const currentIndex = selectedItems.findIndex(e => e.cartProductId === currentCartProduct.cartProductId);
        const newSelected = [...selectedItems];
        if (currentIndex !== -1) {
            newSelected.splice(currentIndex, 1);
            newSelected.push(CartProduct);
            console.log(newSelected)
            setSelectedItems(newSelected);
        }
    }





    const handleIncreaseQuantity = (currentCartProduct) => {
        const increaseUrl = `http://localhost:8080/cart/${userId}/changeQuantity/${currentCartProduct.product.productId}/increase`;
        axios.get(increaseUrl, config)
            .then((response) => {
                setCurrentCartProduct(response.data);

                // handleQuantityChange(response.data)
            })
            .catch((error) => {
                console.error('Error increasing quantity:', error);
            });
    };

    const handleDecreaseQuantity = (currentCartProduct) => {
        const decreaseUrl = `http://localhost:8080/cart/${userId}/changeQuantity/${currentCartProduct.product.productId}/decrease`;
        axios.get(decreaseUrl, config)
            .then((response) => {
                // handleQuantityChange(response.data);
                setCurrentCartProduct(response.data);

            })
            .catch((error) => {
                console.error('Error decreasing quantity:', error);
            });
    };

    return (
        <>
            {currentCartProduct ? (
                <Card>
                    <CardContent>
                        <ListItem key={currentCartProduct.cartProductId}>
                            <FormControlLabel
                                control={
                                    <Checkbox
                                        checked={selectedItems.find(e => e.cartProductId == currentCartProduct.cartProductId)}
                                        onChange={() => handleCheckboxToggle(currentCartProduct)}
                                    />
                                }
                            />
                            <ListItemText
                                primary={currentCartProduct.product.productName}
                                secondary={`Price: Rs${currentCartProduct.product.productPrice}, Quantity: ${currentCartProduct.quantity}`}
                            />

                            <IconButton onClick={() => handleIncreaseQuantity(currentCartProduct)}>
                                <AddCircleOutlineIcon />
                            </IconButton>
                            <IconButton onClick={() => handleDecreaseQuantity(currentCartProduct)}>
                                <RemoveCircleOutlineIcon />
                            </IconButton>
                        </ListItem>
                    </CardContent>
                </Card>
            ) : null}
        </>
    );
}
