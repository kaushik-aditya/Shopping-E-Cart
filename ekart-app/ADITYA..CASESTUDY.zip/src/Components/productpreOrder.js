import React from 'react';
import { useLocation } from 'react-router-dom';
import Button from '@mui/material/Button';
import Grid from '@mui/material/Grid';
import Paper from '@mui/material/Paper';
import Typography from '@mui/material/Typography';
import axios from 'axios';
import { useEffect, useState } from 'react';

export default function ProductPreOrder() {
    const token = localStorage.getItem("token");


    const config = {
        headers: {
            Authorization: `Bearer ${token}`,
        },
    };
    const location = useLocation();
    const productId = location.state.productId;

    const [product,setProduct] = useState({});


    const url = "http://localhost:8080/products/getById/"+productId;
    useEffect(() => {
      
        axios.get(url,config)
          .then((response) => {
            if (response.status === 200) {
              const fetchedProduct = response.data;
              setProduct(fetchedProduct);
            } else {
              console.error('Request failed with status:', response.status);
            }
          })
          .catch((error) => {
            console.error('Error fetching product:', error);
          });
      }, []);


    const addProductInCart = async () => {
        const { userId } = JSON.parse(localStorage.getItem("user"));
        const url = "http://localhost:8080/cart/" + userId + "/add/" + product.productId;
        

        await axios
            .get(url, config)
            .then((response) => {
                if (response.status === 200) {
                    // Product added to cart successfully
                    console.log('Product added to cart:', response.data);
                    // You can perform any additional actions here
                } else {
                    // Handle other status codes or errors if needed
                    console.error('Request failed with status:', response.status);
                }
            })
            .catch((error) => {
                // Handle network errors or other exceptions
                console.error('Error adding product to cart:', error);
                // You can also display an error message to the user if needed
            });


    }


    return (

        <Paper elevation={2} style={{ padding: '20px' , margin : "20px"}}>
            <Grid container spacing={3}>
                {/* Left Half: Product Image */}
                <Grid item xs={12} md={6}>
                    <img src={product.productImage} alt={product.productName} style={{ width: '100%' }} />
                </Grid>

                {/* Right Half: Product Details */}
                <Grid item xs={12} md={6}>
                    <Typography variant="h4" gutterBottom>
                        {product.productName}
                    </Typography>
                    <Typography variant="h5" color="textSecondary" gutterBottom>
                        {product.productBrand}
                    </Typography>

                    <Typography variant="h6" gutterBottom>
                        Rs{product.productPrice}
                    </Typography>
                    <Typography variant="body1" paragraph>
                        {product.productDetails}
                    </Typography>

                    <Button variant="contained" color="primary" maxWidth="md" onClick={addProductInCart}>
                        Add to Bag
                    </Button>
                    
                </Grid>
            </Grid>
        </Paper>

    );
}
