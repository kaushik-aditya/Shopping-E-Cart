import { useContext, useEffect, useState } from "react";
import axios from "axios";
import { Container, Typography, Grid, Paper } from "@mui/material";
import { useNavigate } from "react-router-dom";
import { AuthContext } from "../App";

export default function ProductDetails() {

    const { modifiedProducts } = useContext(AuthContext);

    const [products, setProducts] = useState([]);
    const navigate = useNavigate();
    // Define the getProducts function
    const getProducts = async () => {
        try {
            const url = "http://localhost:8080/products/getAllProducts"; // Remove the extra slashes
            const response = await axios.get(url);

            if (response.status === 200) {
                // Assuming the response contains the products data
                const products = response.data;
                return products;
            } else {
                // Handle other status codes or errors if needed
                throw new Error(`Request failed with status ${response.status}`);
            }
        } catch (error) {
            // Handle network errors or other exceptions
            console.error("Error fetching products:", error);
            throw error;
        }
    };

    const fetchProducts = async () => {
        try {
            const newProducts = await getProducts();
            console.log(newProducts);
            setProducts(newProducts);
        } catch (error) {
            // Handle the error appropriately
            console.error("Error fetching products:", error);
        }
    };
    useEffect(() => {
      
        fetchProducts();
      
    }, [])
    

    useEffect(() => {

        console.log("Setting modified products");
        setProducts(modifiedProducts);
        

    }, [modifiedProducts]); 

    useEffect(() => {
        console.log(products);
    
      
    }, [products])
    


    const showProductDetails = (productId) => {
        navigate(`/product_cart`, { state: { productId } });
    }


    return (
        <Container maxWidth="lg" sx={{marginTop : "40px"}}>
            <Grid container spacing={3}>
                {Array.isArray(products) ? (
                    products.map((product, index) => (
                        <Grid item xs={12} sm={6} md={4} key={index} onClick={() => showProductDetails(product.productId)}>
                            <Paper style={{ border: '2px solid green', padding: '10px', textAlign: 'center' }}>
                                <img src={product.productPic} alt={product.productName} style={{ maxWidth: '100%', height: 'auto' }} />
                                <Typography variant="h6">{product.productName}</Typography>
                                <Typography variant="body1">Rs.{product.productPrice}</Typography>
                                <Typography variant="body2">{product.productSubCategory}</Typography>
                                <Typography variant="body2">{product.productBrand}</Typography>
                                <Typography variant="body2">{product.productCategory}</Typography>
                                <Typography variant="body2">{product.productDetails}</Typography>
                                {/* Add more product details here */}
                            </Paper>
                        </Grid>
                    ))
                ) : (
                    <Typography variant="body1">Loading...</Typography>
                )}
            </Grid>
        </Container>
    );
}
