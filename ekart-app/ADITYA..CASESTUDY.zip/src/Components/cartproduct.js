import React, { useEffect, useState } from 'react';
import Axios from 'axios';
import { Divider, Grid, Paper, Typography } from '@mui/material';
import CartProductsTemplate from './cartproducttemplate';
import { Button } from '@mui/material';
import axios from 'axios';
import { styled } from '@mui/material';
import { Box } from '@mui/material';


export default function CartProducts() {
    const [selectedItems, setSelectedItems] = useState([]);

    const [cartData, setCartData] = useState({});
    const user = JSON.parse(localStorage.getItem('user'));
    const userId = user?.userId;
    const token = localStorage.getItem('token');
    const config = {
        headers: {
            Authorization: `Bearer ${token}`,
        },
    };


    const url = "http://localhost:8080/cart/" + userId + "/getCart";

    useEffect(() => {
        const fetchData = async () => {
            try {
                const response = await Axios.get(url, config);
                const cartData = response.data;
                setCartData(cartData);
            } catch (error) {
                console.error('Error fetching cart data:', error);
            }
        };

        fetchData();
    }, []);


    console.log(cartData);
    let totalPrice = 0;

    {
        selectedItems && (totalPrice = selectedItems.reduce((total, product) => {
            // Assuming each product has a property "productPrice"
            return total + (product.product.productPrice * product.quantity);
        }, 0))
    };

    const orederSelectedProducts = () => {
        const orderUrl = "http://localhost:8080/order/" + userId + "/createOrder";
        
        if(selectedItems){
        axios.post(orderUrl, selectedItems, config)
            .then(response => {
                console.log('Order created successfully:', response.data);
                console.log(selectedItems+"selected")

            })
            .catch(error => {
                // Handle error
                console.error('Error creating order:', error);
                // You can display an error message to the user
            });
        }


    }
    const Item = styled(Paper)(({ theme }) => ({
        backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
        ...theme.typography.body2,
        padding: theme.spacing(1),
        color: theme.palette.text.secondary,
    }));

    return (
        <Box sx={{ flexGrow: 1, marginTop: "15px" }}>

            <Grid container spacing={2}>
                <Grid xs={8}>
                    <Item>
                        <Grid container spacing={2}>
                            {cartData.cartProducts && cartData.cartProducts.map((cartProduct) => (
                                <Grid item xs={12} key={cartProduct.cartProductId}>
                                    <Paper elevation={3}>
                                        {/* Pass cartProduct as cartProducts to CartProductsTemplate */}
                                        <CartProductsTemplate cartProducts={cartProduct} selectedItems={selectedItems} setSelectedItems={setSelectedItems} />
                                    </Paper>
                                </Grid>
                            ))}
                        </Grid>
                    </Item>
                </Grid>
                <Grid xs={4} >
                    <Item>
                        <Typography variant="h4">
                            Price Details{selectedItems.length > 0 && `(${selectedItems.length} Items)`}
                        </Typography>

                        <Divider sx={{ color: "red" }}></Divider>
                        <Typography variant="h5"> Total Price : Rs{totalPrice}</Typography>
                        <Button onClick={() => orederSelectedProducts()}>Order</Button>
                    </Item>

                </Grid>
            </Grid>
        </Box>


    );
}
