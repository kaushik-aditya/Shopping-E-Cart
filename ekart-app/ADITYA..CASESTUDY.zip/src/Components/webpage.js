import { Col ,Row} from "react-bootstrap";

import ProductDetails from "./productdetails";
import AppSideBar from "./appsidebar";

export default function WebPage() {
    return (
        <>
            
            <Row>
                {/* <Col sm="3">
                    <AppSideBar />
                </Col> */}
                
                <Col sm="9" >
                    <ProductDetails />
                </Col>
            </Row>
            
        </>
    );
}
