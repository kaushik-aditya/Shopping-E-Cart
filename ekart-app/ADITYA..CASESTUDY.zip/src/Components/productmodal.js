import React, { useState } from 'react';
import Modal from '@mui/material/Modal';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Typography from '@mui/material/Typography';

export default function ProductModal({ open = false, onClose, onSubmit, product }) {
    const [hasChanged, setHasChanged] = useState(false);
    const [formData, setFormData] = useState({ ...product });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setHasChanged(true);

        // Update the form data with the new value
        setFormData({
            ...formData,
            [name]: value,
        });
    };

    const handleSubmit = (event) => {
        event.preventDefault();
        if (hasChanged) {
            onSubmit(formData);
        }
        onClose();
    };

    const style = {
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        bgcolor: 'cream', // Change the bgcolor to your desired cream color
        border: '2px solid #000',
        boxShadow: 24,
        p: 4,
        width: 600, // Increase the width to make it wider
        height: 400, // Set a specific height
        overflow: 'auto', // Add the overflow property for scrolling
    };

    return (
        <Modal open={open} onClose={onClose}>
            <Box sx={style}>
                <Typography variant="h3" sx={{ margin: 'auto' }}>
                    Edit Product
                </Typography>
                {Object.keys(formData).map((field) => (
                    !(field ==="tags") && (
                    <TextField
                        key={field}
                        name={field}
                        label={field}
                        value={formData[field]}
                        onChange={handleChange}
                        fullWidth
                        margin="normal"
                    />)
                ))}
                <Button variant="contained" onClick={handleSubmit}>
                    Submit
                </Button>
            </Box>
        </Modal>
    );
}
